var name = "Chirag Jobanputra";
var age = 27;
var dateOfBirth = "02-Aug-1989";
var birthPlace = "Bhopal";

console.log("Name: " + name + "\n" + "Age: " + age + "\n" + "Date of Birth: " + dateOfBirth + "\n" + "Place of Birth: " + birthPlace);
